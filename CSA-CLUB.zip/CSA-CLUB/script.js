import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-app.js";
import { getFirestore, collection, getDocs, addDoc, deleteDoc, doc, writeBatch, updateDoc } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-firestore.js";
import { getAuth, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-auth.js";
import { getStorage, ref, uploadBytes, getDownloadURL } from "https://www.gstatic.com/firebasejs/11.0.1/firebase-storage.js";

// ===== FIREBASE CONFIG =====
const firebaseConfig = {
  apiKey: "AIzaSyCfluVaPW2Y3-5wCmYEd1k8vWgDjRgzDqI",
  authDomain: "civic-speech-arts.firebaseapp.com",
  projectId: "civic-speech-arts",
  storageBucket: "civic-speech-arts.firebasestorage.app",
  messagingSenderId: "1040454580763",
  appId: "1:1040454580763:web:f1e316ab7e55a674fd56be",
  measurementId: "G-30HC1YFM2K"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);
const storage = getStorage(app);

// ===== HELPERS =====
function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/[&<>]/g, function(m) {
    if (m === '&') return '&amp;';
    if (m === '<') return '&lt;';
    if (m === '>') return '&gt;';
    return m;
  });
}

function formatDate(timestamp) {
  if (!timestamp) return 'No date';
  const date = new Date(timestamp);
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const year = String(date.getFullYear()).slice(-2);
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  return `${month}-${day}-${year} : ${hours}:${minutes}`;
}

// ---- Upload file to Firebase Storage ----
async function uploadMediaFile(file) {
  const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/bmp', 'video/mp4', 'video/webm', 'video/ogg'];
  if (!allowedTypes.includes(file.type)) {
    throw new Error('File type not allowed. Please upload an image (jpg, png, gif, webp, bmp) or video (mp4, webm, ogg).');
  }
  const path = `posts/${Date.now()}_${file.name}`;
  const storageRef = ref(storage, path);
  await uploadBytes(storageRef, file);
  const downloadURL = await getDownloadURL(storageRef);
  let mediaType = 'image';
  if (file.type.startsWith('video/')) {
    mediaType = 'video';
  }
  return { url: downloadURL, type: mediaType };
}

// ---- Check if link can be embedded ----
function isLinkEmbeddable(link) {
  if (!link) return false;
  if (link.match(/\.(jpe?g|png|gif|webp|bmp)(\?.*)?$/i)) return true;
  if (link.includes('youtube.com/watch?v=') || link.includes('youtu.be/')) return true;
  if (link.includes('tiktok.com/')) return true;
  if (link.includes('instagram.com/')) return true;
  if (link.includes('twitter.com/') || link.includes('x.com/')) return true;
  if ((link.includes('facebook.com/') || link.includes('fb.com/')) && !link.includes('/share/')) return true;
  if (link.match(/\.(mp4|webm|ogg)(\?.*)?$/i)) return true;
  return false;
}

// ---- Generate a link card (always used) ----
function generateLinkCard(link) {
  let domain = '';
  try { domain = new URL(link).hostname; } catch(e) { domain = link; }
  const faviconUrl = `https://www.google.com/s2/favicons?domain=${domain}&sz=64`;
  return `
    <div class="link-card">
      <div class="link-card-favicon">
        <img src="${faviconUrl}" alt="${escapeHtml(domain)}" width="32" height="32" loading="lazy" onerror="this.style.display='none'">
      </div>
      <div class="link-card-info">
        <a href="${escapeHtml(link)}" target="_blank" rel="noopener noreferrer" class="link-card-button">🔗 View</a>
      </div>
    </div>
  `;
}

// ---- Generate embed HTML (if embeddable) ----
function generateEmbed(link) {
  let embedHtml = '';
  let hasEmbed = false;

  if (link.match(/\.(jpe?g|png|gif|webp|bmp)(\?.*)?$/i)) {
    embedHtml = `<img src="${escapeHtml(link)}" alt="post media" class="post-media-img" loading="lazy">`;
    hasEmbed = true;
  }
  else if (link.includes('youtube.com/watch?v=') || link.includes('youtu.be/')) {
    let videoId = '';
    if (link.includes('youtu.be/')) {
      videoId = link.split('youtu.be/')[1].split(/[?#]/)[0];
    } else {
      try { videoId = new URL(link).searchParams.get('v'); } catch(e) { videoId = ''; }
    }
    if (videoId) {
      embedHtml = `<iframe class="post-media-video" src="https://www.youtube.com/embed/${videoId}" frameborder="0" allowfullscreen loading="lazy"></iframe>`;
      hasEmbed = true;
    }
  }
  else if (link.includes('tiktok.com/')) {
    const videoId = link.split('/').pop().split('?')[0];
    embedHtml = `
      <blockquote class="tiktok-embed" cite="${escapeHtml(link)}" data-video-id="${escapeHtml(videoId)}" style="max-width:100%;">
        <section><a href="${escapeHtml(link)}" target="_blank">${escapeHtml(link)}</a></section>
      </blockquote>
    `;
    hasEmbed = true;
  }
  else if (link.includes('facebook.com/') || link.includes('fb.com/')) {
    embedHtml = `
      <div class="fb-post" data-href="${escapeHtml(link)}" data-width="100%">
        <blockquote cite="${escapeHtml(link)}" class="fb-xfbml-parse-ignore">
          <a href="${escapeHtml(link)}" target="_blank">${escapeHtml(link)}</a>
        </blockquote>
      </div>
    `;
    hasEmbed = true;
  }
  else if (link.includes('instagram.com/')) {
    embedHtml = `
      <blockquote class="instagram-media" data-instgrm-permalink="${escapeHtml(link)}" data-instgrm-version="14" style="max-width:100%;">
        <a href="${escapeHtml(link)}" target="_blank">${escapeHtml(link)}</a>
      </blockquote>
    `;
    hasEmbed = true;
  }
  else if (link.includes('twitter.com/') || link.includes('x.com/')) {
    embedHtml = `
      <blockquote class="twitter-tweet">
        <a href="${escapeHtml(link)}" target="_blank">${escapeHtml(link)}</a>
      </blockquote>
    `;
    hasEmbed = true;
  }
  else if (link.match(/\.(mp4|webm|ogg)(\?.*)?$/i)) {
    embedHtml = `<video class="post-media-video" controls><source src="${escapeHtml(link)}" type="video/mp4"></video>`;
    hasEmbed = true;
  }

  return { html: embedHtml, hasEmbed };
}

// ============================================================
//  PUBLIC DATA & RENDER FUNCTIONS
// ============================================================

// ---- ARTICLES ----
const articlesData = [
  { imageUrl: "IMG/ARTICLES/1.jpg" },
  { imageUrl: "IMG/ARTICLES/2.jpg" },
  { imageUrl: "IMG/ARTICLES/3.jpg" },
  { imageUrl: "IMG/ARTICLES/4.jpg" },
  { imageUrl: "IMG/ARTICLES/5.jpg" },
  { imageUrl: "IMG/ARTICLES/6.jpg" },
  { imageUrl: "IMG/ARTICLES/7.jpg" },
  { imageUrl: "IMG/ARTICLES/8.jpg" }
];

function renderArticles() {
  const container = document.getElementById('articlesContainer');
  if (!container) { console.warn('articlesContainer not found'); return; }
  let html = '';
  articlesData.forEach((article, index) => {
    html += `<div class="article-card glass-card reveal" data-full-img="${article.imageUrl}">
      <img src="${article.imageUrl}" alt="Article image ${index + 1}" onerror="this.src='https://placehold.co/600x400?text=No+Image'">
    </div>`;
  });
  container.innerHTML = html;
  container.querySelectorAll('.article-card').forEach(el => el.classList.add('active'));

  document.querySelectorAll('.article-card').forEach(card => {
    card.addEventListener('click', () => {
      const fullImg = card.getAttribute('data-full-img');
      if (fullImg && typeof openLightbox === 'function') openLightbox(fullImg);
    });
  });
}

// ---- TEAM ----
const teamData = {
  adviser: {
    name: "Mr. Client Josh Tillo",
    role: "CSA Adviser",
    imageUrl: "IMG/MEMBER/advisor.jpg"
  },
  infoCards: [
    {
      icon: "fas fa-user-graduate",
      title: "About the Adviser",
      content: "Mr. Client Josh Tillo has been guiding CSA with over 5 years of experience in speech and civic education. He is a renowned public speaking coach and debate mentor."
    },
    {
      icon: "fas fa-trophy",
      title: "Achievements & Additional Info",
      content: "🏆 National Debate Mentor Award 2024<br>📚 Published oratory guide<br>🎤 SPEAKER AT ACT<br>👨‍🏫 Trained 50+ students at ACT School Publication"
    }
  ]
};

function renderTeam() {
  const container = document.getElementById('teamContainer');
  if (!container) { console.warn('teamContainer not found'); return; }
  const html = `
    <div class="adviser-layout">
      <div class="adviser-photo glass-card reveal" id="adviserProfile">
        <img src="${teamData.adviser.imageUrl}" alt="${teamData.adviser.name}">
        <h3 class="adviser-name">${teamData.adviser.name}</h3>
        <p class="adviser-title">${teamData.adviser.role}</p>
      </div>
      <div class="adviser-info-stack">
        <div class="info-card glass-card reveal">
          <h3><i class="${teamData.infoCards[0].icon}"></i> ${teamData.infoCards[0].title}</h3>
          <p>${teamData.infoCards[0].content}</p>
        </div>
        <div class="info-card glass-card reveal">
          <h3><i class="${teamData.infoCards[1].icon}"></i> ${teamData.infoCards[1].title}</h3>
          <p>${teamData.infoCards[1].content}</p>
        </div>
      </div>
    </div>
  `;
  container.innerHTML = html;
  container.querySelectorAll('.reveal, .glass-card, .adviser-photo, .info-card').forEach(el => el.classList.add('active'));

  const profile = document.getElementById('adviserProfile');
  if (profile) {
    profile.addEventListener('click', () => { window.location.href = 'admin.html'; });
  }
}

// ---- LIGHTBOX ----
function openLightbox(imageSrc) {
  const modal = document.getElementById('lightboxModal');
  const img = document.getElementById('lightboxImage');
  if (modal && img) { img.src = imageSrc; modal.style.display = 'flex'; }
}
function closeLightbox() {
  const modal = document.getElementById('lightboxModal');
  if (modal) modal.style.display = 'none';
}

// ---- EMBED SCRIPTS LOADER ----
let embedScriptsLoaded = false;

function loadEmbedScripts() {
  if (embedScriptsLoaded) return;
  embedScriptsLoaded = true;
  if (!document.querySelector('script[src*="tiktok.com/embed.js"]')) {
    const s = document.createElement('script');
    s.src = 'https://www.tiktok.com/embed.js';
    s.async = true;
    document.head.appendChild(s);
  }
  if (!document.querySelector('script[src*="connect.facebook.net"]')) {
    const s = document.createElement('script');
    s.src = 'https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v18.0';
    s.async = true;
    s.defer = true;
    s.crossOrigin = 'anonymous';
    document.head.appendChild(s);
  }
  if (!document.querySelector('script[src*="instagram.com/embed.js"]')) {
    const s = document.createElement('script');
    s.src = '//www.instagram.com/embed.js';
    s.async = true;
    document.head.appendChild(s);
  }
  if (!document.querySelector('script[src*="platform.twitter.com/widgets.js"]')) {
    const s = document.createElement('script');
    s.src = 'https://platform.twitter.com/widgets.js';
    s.async = true;
    document.head.appendChild(s);
  }
}

// ---- POSTS (public) ----
async function renderPosts() {
  const container = document.getElementById('postsContainer');
  if (!container) {
    console.error('❌ postsContainer not found!');
    return;
  }

  container.innerHTML = '<div class="loading-spinner">⏳ Loading posts...</div>';

  try {
    const snapshot = await getDocs(collection(db, "posts"));
    const count = snapshot.size;

    if (count === 0) {
      container.innerHTML = `
        <div style="text-align:center;padding:2rem;color:#aaa;">
          <p>📭 No posts yet.</p>
          <p style="font-size:0.9rem;">
            Add a post from the <a href="admin.html" style="color:#3a86ff;text-decoration:underline;">Admin Panel</a>
          </p>
        </div>
      `;
      container.querySelectorAll('.reveal').forEach(el => el.classList.add('active'));
      return;
    }

    let html = '';
    let hasEmbed = false;

    for (const doc of snapshot.docs) {
      const post = doc.data();
      const title = escapeHtml(post.title) || 'Untitled';
      const date = escapeHtml(post.date) || '';
      const description = escapeHtml(post.description) || '';
      const link = post.link || '';
      const mediaUrl = post.mediaUrl || '';
      const mediaType = post.mediaType || '';

      const embeddable = isLinkEmbeddable(link);
      const hasMedia = mediaUrl && mediaUrl.trim() !== '' && mediaType;

      // Skip if not embeddable and no media
      if (!embeddable && !hasMedia) {
        console.log(`⚠️ Skipping post "${title}" – no embeddable content and no media.`);
        continue;
      }

      let mediaHtml = '';
      let embedType = 'none';

      if (embeddable) {
        const embedResult = generateEmbed(link);
        mediaHtml = embedResult.html;
        if (embedResult.hasEmbed) {
          embedType = 'embed';
          hasEmbed = true;
        }
      } else if (hasMedia) {
        if (mediaType === 'image') {
          mediaHtml = `<img src="${escapeHtml(mediaUrl)}" alt="${title}" class="post-media-img" loading="lazy">`;
          embedType = 'image';
        } else if (mediaType === 'video') {
          mediaHtml = `<video class="post-media-video" controls><source src="${escapeHtml(mediaUrl)}" type="video/mp4"></video>`;
          embedType = 'video';
        }
      }

      const linkCardHtml = generateLinkCard(link);
      const finalMedia = mediaHtml ? `${mediaHtml}${linkCardHtml}` : linkCardHtml;

      html += `
        <div class="post-card glass-card reveal" data-embed="${embedType}">
          ${date ? `<div class="post-date">📅 ${date}</div>` : ''}
          <h3 class="post-title">${title}</h3>
          ${finalMedia}
          ${description ? `<p class="post-description">${description}</p>` : ''}
        </div>
      `;
    }

    if (html === '') {
      container.innerHTML = `
        <div style="text-align:center;padding:2rem;color:#aaa;">
          <p>📭 No visible posts yet (some posts need media).</p>
          <p style="font-size:0.9rem;">
            Check the <a href="admin.html" style="color:#3a86ff;text-decoration:underline;">Admin Panel</a> to add media.
          </p>
        </div>
      `;
    } else {
      container.innerHTML = html;
    }

    container.querySelectorAll('.post-card, .glass-card, .reveal').forEach(el => el.classList.add('active'));

    if (hasEmbed) {
      loadEmbedScripts();
    }

  } catch (error) {
    console.error('❌ renderPosts error:', error);
    container.innerHTML = `
      <div style="color:#ff7b72;text-align:center;padding:2rem;">
        ❌ Error loading posts: ${error.message}
        <br><br>
        <button onclick="location.reload()" style="background:#3a86ff;border:none;padding:0.5rem 1.5rem;border-radius:40px;color:white;cursor:pointer;">Retry</button>
      </div>
    `;
    container.querySelectorAll('div').forEach(el => el.style.opacity = '1');
  }
}

// ---- CONTACT FORM ----
async function saveMessageToFirestore(name, message) {
  try {
    await addDoc(collection(db, "contacts"), {
      name,
      message,
      timestamp: new Date().toISOString(),
      read: false
    });
    return true;
  } catch (error) { console.error(error); return false; }
}

// ============================================================
//  ADMIN FUNCTIONS
// ============================================================

let currentAdminUser = null;

// Helper to create file input and get upload result
function createFileInput(accept, callback) {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = accept;
  input.style.display = 'none';
  document.body.appendChild(input);
  input.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (file) {
      try {
        const result = await uploadMediaFile(file);
        callback(result);
      } catch (err) {
        alert('Upload failed: ' + err.message);
        callback(null);
      }
    } else {
      callback(null);
    }
    document.body.removeChild(input);
  });
  input.click();
}

function initAdmin() {
  const loginCard = document.getElementById('loginCard');
  const dashboardCard = document.getElementById('dashboardCard');
  const loginBtn = document.getElementById('loginButton');
  const loginEmail = document.getElementById('loginEmail');
  const loginPassword = document.getElementById('loginPassword');
  const loginError = document.getElementById('loginError');
  const logoutBtn = document.getElementById('logoutBtn');
  const messagesContainer = document.getElementById('messagesContainer');
  const messageCount = document.getElementById('messageCount');
  const clearMessagesBtn = document.getElementById('clearMessagesBtn');
  const addPostBtn = document.getElementById('addPostBtn');
  const postsList = document.getElementById('postsList');

  const inboxTab = document.getElementById('inboxTab');
  const postsTab = document.getElementById('postsTab');
  const inboxPanel = document.getElementById('inboxContent');
  const postsPanel = document.getElementById('postsContent');

  if (!loginCard) return;

  function switchTab(tab) {
    inboxTab.classList.toggle('active', tab === 'inbox');
    postsTab.classList.toggle('active', tab === 'posts');
    inboxPanel.classList.toggle('active', tab === 'inbox');
    postsPanel.classList.toggle('active', tab === 'posts');
    if (tab === 'inbox') loadMessages();
    if (tab === 'posts') loadPosts();
  }

  inboxTab.addEventListener('click', () => switchTab('inbox'));
  postsTab.addEventListener('click', () => switchTab('posts'));

  loginBtn.addEventListener('click', async () => {
    const email = loginEmail.value.trim();
    const password = loginPassword.value.trim();
    if (!email || !password) { loginError.textContent = 'Please fill both fields.'; return; }
    try {
      await signInWithEmailAndPassword(auth, email, password);
      loginError.textContent = '';
    } catch (e) {
      loginError.textContent = 'Login failed: ' + e.message;
    }
  });

  logoutBtn.addEventListener('click', async () => { await signOut(auth); });

  onAuthStateChanged(auth, (user) => {
    currentAdminUser = user;
    if (user) {
      loginCard.style.display = 'none';
      dashboardCard.style.display = 'flex';
      switchTab('inbox');
    } else {
      loginCard.style.display = 'block';
      dashboardCard.style.display = 'none';
    }
  });

  // ===== MESSAGES (unchanged) =====
  async function loadMessages() {
    if (!currentAdminUser) return;
    try {
      const snapshot = await getDocs(collection(db, "contacts"));
      const docs = snapshot.docs;
      let unreadCount = 0;
      docs.forEach(doc => {
        const data = doc.data();
        if (data.read === undefined || data.read === false) unreadCount++;
      });
      messageCount.textContent = unreadCount;

      messagesContainer.innerHTML = '';
      if (docs.length === 0) {
        messagesContainer.innerHTML = '<p class="empty-msg">📭 No messages yet.</p>';
        return;
      }
      docs.forEach(doc => {
        const data = doc.data();
        const id = doc.id;
        const isUnread = (data.read === undefined || data.read === false);
        const div = document.createElement('div');
        div.className = `message-item ${isUnread ? 'unread' : ''}`;
        div.dataset.id = id;
        div.innerHTML = `
          <div class="message-sender">${escapeHtml(data.name)}</div>
          <div class="message-text">${escapeHtml(data.message)}</div>
          <div class="message-date">${formatDate(data.timestamp)}</div>
          <div class="message-actions">
            <button class="copy-btn" onclick="copyMessage(this)">📋 Copy</button>
            ${isUnread ? `<button class="okay-btn" onclick="markAsRead('${id}')">✅ Okay</button>` : ''}
            <button class="delete-btn" onclick="deleteSingleMessage('${id}')">🗑️ Delete</button>
          </div>
        `;
        messagesContainer.appendChild(div);
      });
    } catch (error) {
      console.error(error);
      messagesContainer.innerHTML = `<p class="error-msg">❌ Error loading messages: ${error.message}</p>`;
    }
  }

  window.markAsRead = async function(id) {
    if (!currentAdminUser) return;
    try {
      await updateDoc(doc(db, "contacts", id), { read: true });
      await loadMessages();
    } catch (error) { alert('Error marking as read: ' + error.message); }
  };

  window.deleteSingleMessage = async function(id) {
    if (!currentAdminUser) return;
    if (!confirm('Delete this message?')) return;
    try {
      await deleteDoc(doc(db, "contacts", id));
      await loadMessages();
      alert('Message deleted.');
    } catch (error) { alert('Error deleting message: ' + error.message); }
  };

  window.copyMessage = function(button) {
    const messageText = button.closest('.message-item').querySelector('.message-text').textContent;
    navigator.clipboard.writeText(messageText).then(() => {
      const original = button.textContent;
      button.textContent = '✅ Copied!';
      setTimeout(() => { button.textContent = original; }, 2000);
    }).catch(() => {
      const textarea = document.createElement('textarea');
      textarea.value = messageText;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      const original = button.textContent;
      button.textContent = '✅ Copied!';
      setTimeout(() => { button.textContent = original; }, 2000);
    });
  };

  clearMessagesBtn.addEventListener('click', async () => {
    if (!confirm('Delete ALL messages?')) return;
    try {
      const snapshot = await getDocs(collection(db, "contacts"));
      const batch = writeBatch(db);
      snapshot.forEach(d => batch.delete(d.ref));
      await batch.commit();
      await loadMessages();
      alert('All messages cleared.');
    } catch (error) { alert('Error: ' + error.message); }
  });


  async function loadPosts() {
    if (!currentAdminUser) return;
    try {
      const snapshot = await getDocs(collection(db, "posts"));
      postsList.innerHTML = '';
      if (snapshot.empty) {
        postsList.innerHTML = '<p class="empty-msg">📝 No posts yet. Add one above.</p>';
        return;
      }
      snapshot.forEach(docSnap => {
        const data = docSnap.data();
        const link = data.link || '';
        const mediaUrl = data.mediaUrl || '';
        const mediaType = data.mediaType || '';
        const embeddable = isLinkEmbeddable(link);
        const hasMedia = mediaUrl && mediaUrl.trim() !== '' && mediaType;
        const isValid = embeddable || hasMedia;

        const div = document.createElement('div');
        div.className = 'post-item';
        if (!isValid) {
          div.classList.add('invalid-link');
        } else {
          div.classList.add('valid-link');
        }
        let mediaBadge = '';
        if (hasMedia) {
          mediaBadge = `<span class="media-badge">✅ Media attached</span>`;
        }
        div.innerHTML = `
          <strong>${escapeHtml(data.title) || 'Untitled'}</strong>
          <a href="${escapeHtml(link)}" target="_blank" class="post-link">${escapeHtml(link)}</a>
          <span class="post-meta">📅 ${escapeHtml(data.date) || 'No date'}</span>
          <span class="post-meta">📝 ${escapeHtml(data.description) || 'No description'}</span>
          ${mediaBadge}
          ${!isValid ? `<div class="invalid-warning">⚠️ Link not embeddable – add an image/video instead.</div>` : ''}
          <div class="post-actions">
            ${!isValid ? `<button class="inline-btn add-media-btn" data-id="${docSnap.id}">📷 Add Photo/Video</button>` : ''}
            <button class="inline-btn edit-post" data-id="${docSnap.id}">✏️ Edit</button>
            <button class="inline-btn delete-btn delete-post" data-id="${docSnap.id}">🗑️ Delete</button>
          </div>
        `;
        postsList.appendChild(div);
      });

      document.querySelectorAll('.add-media-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
          const id = btn.dataset.id;
          createFileInput('image/*,video/*', async (result) => {
            if (result && result.url) {
              try {
                await updateDoc(doc(db, "posts", id), { 
                  mediaUrl: result.url,
                  mediaType: result.type 
                });
                await loadPosts();
                await renderPosts();
                alert('✅ Media added successfully!');
              } catch (err) {
                alert('Error saving media: ' + err.message);
              }
            } else {
              alert('Upload cancelled or failed. Post remains invalid.');
            }
          });
        });
      });
      document.querySelectorAll('.edit-post').forEach(btn => {
        btn.addEventListener('click', async () => {
          const id = btn.dataset.id;
          await editPost(id);
        });
      });
      document.querySelectorAll('.delete-post').forEach(btn => {
        btn.addEventListener('click', async () => {
          const id = btn.dataset.id;
          await deletePost(id);
        });
      });
    } catch (error) {
      console.error(error);
      postsList.innerHTML = `<p class="error-msg">❌ Error loading posts.</p>`;
    }
  }

  async function editPost(id) {
    const newLink = prompt('Enter new link (URL):');
    if (!newLink) return;
    const newTitle = prompt('Title (optional):', '');
    const newDate = prompt('Date (optional):', '');
    const newDesc = prompt('Description (optional):', '');
    const updates = { link: newLink };
    if (newTitle) updates.title = newTitle;
    if (newDate) updates.date = newDate;
    if (newDesc) updates.description = newDesc;

    if (!isLinkEmbeddable(newLink)) {
      const choice = confirm('The link is not embeddable. Would you like to upload an image/video now? Click OK to upload, Cancel to keep current media.');
      if (choice) {
        createFileInput('image/*,video/*', async (result) => {
          if (result && result.url) {
            updates.mediaUrl = result.url;
            updates.mediaType = result.type;
            await updateDoc(doc(db, "posts", id), updates);
            await loadPosts();
            await renderPosts();
            alert('✅ Post updated with media.');
          } else {
            alert('Upload cancelled – media not changed.');
          }
        });
        return;
      }
    }
    try {
      await updateDoc(doc(db, "posts", id), updates);
      await loadPosts();
      await renderPosts();
      alert('✅ Post updated.');
    } catch (error) { alert('Error: ' + error.message); }
  }

  async function deletePost(id) {
    if (!confirm('Delete this post?')) return;
    try {
      await deleteDoc(doc(db, "posts", id));
      await loadPosts();
      await renderPosts();
      alert('Post deleted.');
    } catch (error) { alert('Error: ' + error.message); }
  }

  addPostBtn.addEventListener('click', async () => {
    const link = prompt('Enter the post URL (link):');
    if (!link) return;
    const title = prompt('Title (optional):');
    const date = prompt('Date (optional):');
    const desc = prompt('Short description (optional):');
    let mediaUrl = '';
    let mediaType = '';

    if (!isLinkEmbeddable(link)) {
      const choice = confirm('The link is not embeddable. You must upload an image or video to make this post visible. Click OK to upload.');
      if (!choice) {
        alert('Post not added without media.');
        return;
      }
      const uploadPromise = new Promise((resolve) => {
        createFileInput('image/*,video/*', (result) => {
          if (result && result.url) {
            mediaUrl = result.url;
            mediaType = result.type;
          }
          resolve();
        });
      });
      await uploadPromise;
      if (!mediaUrl) {
        alert('Upload failed or cancelled. Post not added.');
        return;
      }
    }

    try {
      await addDoc(collection(db, "posts"), {
        link,
        title: title || '',
        date: date || '',
        description: desc || '',
        mediaUrl: mediaUrl || '',
        mediaType: mediaType || ''
      });
      await loadPosts();
      await renderPosts();
      alert('✅ Post added successfully!');
    } catch (error) { alert('Error: ' + error.message); }
  });

  window.loadMessages = loadMessages;
  window.loadPosts = loadPosts;
}


function initPublic() {
  if (document.getElementById('loginCard')) return;
  console.log('✅ Public site initializing...');

  const cursorGlow = document.querySelector('.cursor-glow');
  if (cursorGlow) {
    document.addEventListener('mousemove', (e) => {
      cursorGlow.style.transform = `translate(${e.clientX}px, ${e.clientY}px)`;
    });
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('active'); observer.unobserve(e.target); } });
  }, { threshold: 0.2 });

  document.querySelectorAll('a[href^="#"]:not(.post-card)').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });

  const form = document.getElementById('clubForm');
  const feedback = document.getElementById('formFeedback');
  if (form) {
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = document.getElementById('name').value.trim();
      const msg = document.getElementById('message').value.trim();
      if (!name || !msg) {
        feedback.innerHTML = '<span style="color:#ff7b72;">❌ Please fill both fields.</span>';
        setTimeout(() => feedback.innerHTML = '', 3000);
        return;
      }
      const saved = await saveMessageToFirestore(name, msg);
      if (saved) {
        feedback.innerHTML = '<span style="color:#0f0;">✅ Message sent! Admin will see it.</span>';
        form.reset();
      } else {
        feedback.innerHTML = '<span style="color:#ff7b72;">⚠️ Database error.</span>';
      }
      setTimeout(() => feedback.innerHTML = '', 4000);
    });
  }

  const yearSpan = document.getElementById('currentYear');
  if (yearSpan) yearSpan.textContent = new Date().getFullYear();

  document.querySelectorAll('.glass-card').forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      card.style.transform = `perspective(1000px) rotateX(${(e.clientY - rect.top - rect.height/2)/40}deg) rotateY(${(e.clientX - rect.left - rect.width/2)/40}deg) translateY(-5px)`;
    });
    card.addEventListener('mouseleave', () => card.style.transform = '');
  });

  const sections = document.querySelectorAll('section');
  const navItems = document.querySelectorAll('.nav-item');
  function setActiveNav() {
    let current = '';
    const scrollPos = window.scrollY + 160;
    sections.forEach(section => {
      if (scrollPos >= section.offsetTop && scrollPos < section.offsetTop + section.offsetHeight) current = section.id;
    });
    navItems.forEach(item => {
      item.classList.remove('active-section');
      if (item.getAttribute('href') === `#${current}`) item.classList.add('active-section');
    });
  }
  window.addEventListener('scroll', setActiveNav);

  const lightModal = document.getElementById('lightboxModal');
  if (lightModal) {
    lightModal.addEventListener('click', (e) => { if (e.target === lightModal) closeLightbox(); });
    const closeBtn = lightModal.querySelector('.close-lightbox');
    if (closeBtn) closeBtn.addEventListener('click', closeLightbox);
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && lightModal.style.display === 'flex') closeLightbox(); });
  }

  renderArticles();
  renderTeam();
  renderPosts();

  document.querySelectorAll('.reveal, .reveal-left, .reveal-right, .post-card, .article-card, .info-card, .adviser-photo').forEach(el => {
    if (!el.classList.contains('active')) {
      el.classList.add('active');
    }
    observer.observe(el);
  });
  setActiveNav();
}


document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('loginCard')) {
    console.log('Admin page detected.');
    initAdmin();
  } else {
    console.log('Public page detected.');
    initPublic();
  }
});